# -*- coding: utf-8 -*-
"""
Created on Thu Sep 29 13:27:22 2022

@author: plasma
"""

import numpy as np
import LT.box as B

d = B.get_file('DAC2Voltage_Calibration.data')

o = open('DAC2Voltage_Calibration.txt', 'w')

for ld in d.data:
    line = ''.join([f'{ld[k]}'+'\t' for k in d.keys[:-1]])
    o.write(line[:-1]+'\n')
    
o.close()



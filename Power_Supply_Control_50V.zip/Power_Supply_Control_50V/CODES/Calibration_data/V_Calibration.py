# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 11:57:09 2021
This program is used to plot the DAC2Voltage Calibration data
"""
import numpy as np
import LT.box as B
import matplotlib.pyplot as plt

d = np.loadtxt('C:/Users/plasma/Desktop/Power_Supply_Control_50V/Calibration_data/DAC2Voltage_Calibration.txt')
#d = np.loadtxt('C:/Users/plasma/Desktop/Power_Supply_Control_50V/Calibration_data/DAC2ADC_Calibration.txt')

DAC = d[:,0]
V1  = d[:,1]
V2  = d[:,2]
V3  = d[:,3]
V4  = d[:,4]
V5  = d[:,5]
V6  = d[:,6]
V7  = d[:,7]
V8  = d[:,8]
"""
#Plotting the DAC Calibration data as a function of Voltage:
plt.figure(1)
plt.plot(DAC, V1, label='V1')
plt.plot(DAC, V2, label='V2')
plt.plot(DAC, V3, label='V3')
plt.plot(DAC, V4, label='V4')
plt.plot(DAC, V5, label='V5')
plt.plot(DAC, V6, label='V6')
plt.plot(DAC, V7, label='V7')
plt.plot(DAC, V8, label='V8')

plt.xlabel('DAC Analog Number')
plt.ylabel('Voltage')
plt.legend()

p = B.polyfit(DAC, V8, order =2)
B.plot_exp(DAC, V8)
B.plot_line(p.xpl, p.ypl)
#plt.xlabel('DAC Analog Number')
#plt.ylabel('Voltage (V)')
#plt.legend()
"""


#Plotting the Voltage Calibration data as a function of DAC:
plt.figure(2)
plt.plot(V8, DAC, label='V8')

plt.ylabel('DAC Analog Number')
plt.xlabel('Voltage')
plt.legend()

p = B.polyfit(V8,DAC, order =2)
B.plot_exp(V8, DAC)
B.plot_line(p.xpl, p.ypl)
#plt.xlabel('DAC Analog Number')
#plt.ylabel('Voltage (V)')
#plt.legend()

plt.show()


"""
v(dac)
Ch1: a0 = 21.1702297530, a1= 67.968480024 , a2= 0.0014035641
Ch2: a0 = 21.6977530091, a1= 68.0049052039, a2= 0.0013801614 
Ch3: a0 = 21.2229714475, a1= 67.822683508 , a2= 0.00201917309
Ch4: a0 = 21.5625515306, a1= 67.8972884729, a2= 0.0014058342 
Ch5: a0 = 22.0794449925, a1= 67.3301750431, a2= 0.004658043888
Ch6: a0 = 21.4221665609, a1= 67.8826406531, a2= 0.001797708583
Ch7: a0 = 21.6775948326, a1= 67.9290741355, a2= 0.001877432149
Ch8: a0 = 21.4099562268, a1= 68.0258912106, a2= 0.001398646545
"""




"""
DAC(V)
Ch1: a0 = -0.3115114017, a1= 0.01471296745, a2= -4.4864240859
Ch2: a0 = -0.3191103286, a1= 0.01470510668, a2= -4.4109499281
Ch3: a0 = -0.3129731724, a1= 0.01474469894, a2= -6.4856316073
Ch4: a0 = -0.3176160295, a1= 0.01472839669, a2= -4.5070079472
Ch5: a0 = -0.3286968478, a1= 0.01485436388, a2=-1.56420192082
Ch6: a0 = -0.3156213950, a1= 0.01473163196, a2= -5.7591928382
Ch7: a0 = -0.3191891348, a1= 0.01472162350, a2= -6.0156334426
Ch8: a0 = -0.3147796781, a1= 0.01470056613, a2= -4.4641249029
"""
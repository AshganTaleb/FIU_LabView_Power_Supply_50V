These LabVIEW examples were created using LabVIEW 2016 version 16.0 (32 bit)  April 2017

Follow these steps when using the LabVIEW examples.

(1) Create a folder on your desktop and name:   LabVIEW

(2) Copy the VI and DLL files to this folder*.

(3) Load the VI from the desktop folder (you should be logged on to Windows as administrator and also start LabVIEW by right clicking the LabVIEW program icon and click "Run as administrator"). Load the dac-8u10.dll DLL

(4) The DAC-8U10 device driver (or simulator) must be loaded, you will see a red 8 icon in your system tray to confirm this.

(5) Run the VI.

(6) Type the MS byte for channel 1 in the box labeled Relay Byte 1 and the LS byte for channel 1 in the box labeled Relay Byte 2. Click the Send Bytes button to set the analog level for channel 1.    Please note that this example works with both the AR-12MF Relay Interface, the DAC-8U10 and other Digital to Analog converters. The only difference is you load different DLLs.



* if you later move the DLL, you must reload the DLL file (as shown in step 2 on the front panel). Issues have been reported about the previous DLL loading when an updated version is selected. To prevent this, delete the original folder so that LabVIEW can not find the DLL. You should also verify the assembly version after it loads.


NOTE: You may need to set the LabVIEW .Net configuration file to use the same .Net version as the DLL. The .Net version must be 4.0 or later in order to read memory labels. We have DLL versions that have been compiled using both 32 or 64 bit libraries and also with different .Net versions that may be used to solve issues.

Please contact EECI support at (937) 349-6000 or support@eeci.com if you encounter any problems.
